Longform, Copyright 2015 Cohhe https://cohhe.com/
Longform is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see http://www.gnu.org/licenses/

Longform is based on Underscores http://underscores.me/, (coffee) 2012-2014 Automattic, Inc.

Longform bundles the following third-party resources:

Genericons icon font, Copyright 2013 Automattic
Genericons are licensed under the terms of the GNU GPL, Version 2.
Source: http://www.genericons.com

GLYPHICONS, Copyright 2010 - 2015 Jan Kovařík
GLYPHICONS is licensed under the GPLv3.0
Source: http://glyphicons.com

Theme Options UI Builder, Copyright 2014 Derek Herman
Theme Options UI Builder is locensed under the terms of the GPL, Version 3.
Source: https://wordpress.org/plugins/option-tree

Bootstrap, Copyright 2015 Twitter
Bootstrap is released under the MIT license
Source: http://getbootstrap.com

HTML5 Shiv, Copyright 2014 Alexander Farkas (aFarkas)
HTML5 Shiv is licensed under GPL version 2
Source: https://github.com/aFarkas/html5shiv

Used images in screenshot.png, licensed under CC0 Public Domain, free for commercial use / no attribution required
https://pixabay.com/en/purple-grapes-vineyard-napa-valley-553463/
https://pixabay.com/en/blue-eyes-woman-female-makeup-237438/
https://pixabay.com/en/vintage-woman-pretty-glamorous-635244/
https://pixabay.com/en/giraffe-animal-funny-614141/
https://pixabay.com/en/sheep-grass-agriculture-farm-animal-336474/
https://pixabay.com/en/photographer-photography-349874/
https://pixabay.com/en/puppy-dog-canine-faithful-dog-eyes-336707/
https://download.unsplash.com/uploads/141223808515744db9995/3361b5e1 (unsplash.com)
http://www.pexels.com/photo/sea-mountains-nature-water-3245/
